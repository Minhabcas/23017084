class Stack:
    def __init__(self):
        self.data = []
    
    def push(self, item: str):
        if not isinstance(item, str):
            raise ValueError("Only strings can be pushed onto the stack.")
        self.data.append(item)
    
    def pop(self) -> str:
        if self.is_empty():
            raise IndexError("Pop from an empty stack.")
        return self.data.pop()
    
    def peek(self) -> str:
        if self.is_empty():
            raise IndexError("Peek from an empty stack.")
        return self.data[-1]
    
    def is_empty(self) -> bool:
        return len(self.data) == 0
    
    def __str__(self) -> str:
        return "Stack(" + ", ".join(self.data) + ")"