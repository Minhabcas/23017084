class Animal:
    def eat(self):
        return "Eating..."