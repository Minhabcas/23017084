import random
class RandomList:
    def __init__(self, *args):
        self._list = list(args)
    
    def append(self,*args):
        self.args.append(args)
    
    def get_random_element(self):
        if not self._list:
            raise IndexError("Cannot get a random element from an empty list.")
        index = random.randrange(len(self._list))
        return self._list.pop(index)
