class EmailValidator:
  def __init__(self, min_length, mails, domains):
    self.min_length = min_length
    self.mails = mails
    self.domains = domains
  def __validate_name(self, name):
    if len(name) >= self.min_length:
      return True
    else:
      return False
  def __validate_mail(self, mail):
    if mail in self.mails:
      return True
    else:
      return False
  def __validate_domain(self, domain):
    if domain in self.domains:
      return True
    else:
      return False
  def validate(self, mail):
    if "@" not in mail:
      return False
    phan = mail.split("@")
    if len(phan) != 2:
      return False
    if len(phan) < self.__validate_name(phan[0]):
      return False
    if not self.__validate_domain(phan[1]):
      return False
    return True 
mails = ["gmail", "softuni"]
domains = ["com", "bg"]
email_validator = EmailValidator(6, mails, domains)
print(email_validator.validate("pe77er@gmail.com"))
print(email_validator.validate("georgios@gmail.net"))
print(email_validator.validate("stamatito@abv.net"))
print(email_validator.validate("abv@softuni.bg"))