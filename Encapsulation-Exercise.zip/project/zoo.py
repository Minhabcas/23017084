
from lion import Lion
from tiger import Tiger
from cheetah import Cheetah
from keeper import Keeper
from vet import Vet
from caretaker import Caretaker

class Zoo:
    def __init__(self, name, budget, animal_capacity, workers_capacity):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals = []
        self.workers = []
    def add_animal(self, animal, price):
        if len(self.animals) < self.__animal_capacity:
            if self.__budget >= price:
                self.animals.append(animal)
                self.__budget -= price
                return f"{animal.name} the {animal.__class__.__name__} added to the zoo."
            else:
                return "Not enough budget."
        else:
            "Not enough space for animal."
    
    def hire_woker(self, worker):
        if len(self.workers) < self.__workers_capacity:
            self.workers.append(worker)
            return "{worker.name} the {worker.__class__.__name__} added to the zoo"
        else:
            return "Not enough space for worker."
    
    def fire_worker(self, worker_name):
        for i in self.workers:
            if i.name == worker_name:
                self.workers.remove(worker_name)
                return f"{worker_name} fired successfully"
            else:
                return f"There is no {worker_name} in the zoo"
    
    def pay_workers(self):
        total_salary = sum(self.salary for worker in self.workers)
        if total_salary <= self.__budget:
            left_budget = self.__budget - total_salary
            return f"You payed your workers. They are happy. Budget left: {left_budget}"
        else:
            return "You have no budget to pay your workers. They are unhappy."
        
    def tend_animals(self):
        total_tend = sum(animal.get_need() for animal in self.animals)
        if total_tend <= self.__budget:
            left_budget = self.__budget - total_tend
            return f"You payed your workers. They are happy. Budget left: {left_budget}"
        else:
            return "You have no budget to tend your workers. They are unhappy."
    
    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        lions = [str(animal) for animal in self.animals if isinstance(animal, Lion)]
        tigers = [str(animal) for animal in self.animals if isinstance(animal, Tiger)]
        cheetahs = [str(animal) for animal in self.animals if isinstance(animal, Cheetah)]
        
        return (
            f"You have {len(self.animals)} animals\n"
            f"----- {len(lions)} Lions:\n" + "\n".join(lions) + "\n"
            f"----- {len(tigers)} Tigers:\n" + "\n".join(tigers) + "\n"
            f"----- {len(cheetahs)} Cheetahs:\n" + "\n".join(cheetahs)
        )

    def workers_status(self):
        keepers = [str(worker) for worker in self.workers if isinstance(worker, Keeper)]
        caretakers = [str(worker) for worker in self.workers if isinstance(worker, Caretaker)]
        vets = [str(worker) for worker in self.workers if isinstance(worker, Vet)]
        
        return (
            f"You have {len(self.workers)} workers\n"
            f"----- {len(keepers)} Keepers:\n" + "\n".join(keepers) + "\n"
            f"----- {len(caretakers)} Caretakers:\n" + "\n".join(caretakers) + "\n"
            f"----- {len(vets)} Vets:\n" + "\n".join(vets)
        )
