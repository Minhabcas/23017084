class Hero:
    def __init__(self, name, health):
        self.name = name
        self.health = health
    def defend(self, damage):
        self.damage = damage
        self.health -= damage
        if self.health <= 0:
            return f"{self.name} was defeated."
    def heal(self, amount):
        self.amount = amount
        self.health += amount
hero = Hero("Minh",100)
print(hero.defend(20))
hero.heal(10)
print(hero.defend(30))
print(hero.defend(20))
