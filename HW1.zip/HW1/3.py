class Employee:
    def __init__(self, id, name, salary):
        self.id = id
        self.name = name
        self.salary = salary
    def get_full_name(self):
        return f"My name is {self.name}."
    def tongluong(self):
        s = self.salary*12
        print(f"Tổng lương là {s}.")
    def luongtang(self, amount):
        self.amount =amount
        self.salary += amount
        return f"Mức lương sau khi tăng là {self.salary}."
employee = Employee(18052005, 'Minh', 1000)
print(employee.get_full_name())
print(employee.luongtang(1000))
print(employee.tongluong())
