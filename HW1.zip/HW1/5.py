class Cup:
    def __init__(self, size, quantity):
        self.size = size
        self.quantity = quantity
    def fill(self, mm):
        self.mm = mm
        self.quantity += mm
        if self.size - self.quantity == 0:
            print(f"Cup is fulled")
    def status(self):
        return abs(self.size - self.quantity)
cup = Cup(100, 50)
print(cup.status())
cup.fill(40)
cup.fill(20)
print(cup.status())
