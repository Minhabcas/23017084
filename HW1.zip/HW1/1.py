import numpy as np

class Shop:
  def __init__(self, name, items):
    self.name = name
    self.items = items
  def get_items_count(self):
    return len(self.items)
    
shop = Shop("Cua hang cua toi", ["Táo", "Chuối", "Dưa chuột"])
print(shop.get_items_count())