#Bài 2: Integer
import math
class Integer:
    def __init__(self, value:int):
        self.value = value
    @classmethod
    def from_float(cls, value: float):
        if not isinstance(value, float):
            return "value is not a float."
        floored_value = math.floor(value)
        return Integer(floored_value)
    @classmethod
    def from_roman(cls, value: str):
        if not isinstance(value, str):
            return "Value is not string."
        dinhdang = {"I":1, "V":5, "X":10, "L":50, "C":100}
        tong = 0
        pre_value = 0
        for i in reversed(value):
            if i not in dinhdang:
                return "Không xác định!."
            cur_value = dinhdang[i]
            if cur_value >= pre_value:
                tong += cur_value
            else:
                tong -= cur_value
            pre_value = cur_value
        return Integer(tong)
    @classmethod
    def from_string(cls, value):
        if not isinstance(value, str):
            return "wrong type."
        try: #Cố chuyển đổi 
            int_value = int(value)
            return cls(int_value)
        except ValueError: #Xử lí lỗi
            return "wrong type"
    
    def add(self, integer):
        if not isinstance(integer, Integer):
            return "Number should be an Integer instance."
        return Integer(integer.value + self.value).value #Trả về integer mới với giá trị tổng

S1 = Integer(10)
S2 = Integer.from_roman("IV")
print(S2)
print(Integer.from_float("2.6")) #Truyền vào 1 chuỗi"2.6"
print(Integer.from_string(2.6))
print(S1.add(S2))

