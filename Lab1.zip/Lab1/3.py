class Calculator:
    @staticmethod
    def add(*args): #Tổng
        return sum(args)
    
    @staticmethod
    def multiply(*args): #Tích
        result = 1
        for i in args:
            result *= i
        return result
        
    @staticmethod
    def divide(*args): #Chia
        if len(args) == 0:
            return "khong co so de chia."
        result = args[0]
        for i in args[1:]:
            if i == 0:
                return "Khong the chia cho 0."
            result /= i
        return result         
    
    @staticmethod
    def subtract(*args): #Trừ
        if len(args) == 0:
            return "Ko co gia tri nao!"
        result = args[0]
        for i in args[1:]:
            result -= i
        return result
print(Calculator.add(5, 10, 4))
print(Calculator.multiply(1, 2, 3, 5))
print(Calculator.divide(100,2))
print(Calculator.subtract(90, 20, -50, 43, 7))