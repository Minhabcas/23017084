
class Room:
    def __init__(self, number:int, capacity:int):
        self.number = number
        self.capacity = capacity
        self.guest = 0
        self.is_taken = False
    
    def take_room(self,people):
        if self.is_taken:
            return f"Room {self.number} cannot be taken."
        if self.capacity < people:
            return f"Room {self.number} cannot be taken."
        self.guest = people
        self.is_taken = True
        return f"Room {self.number} has been taken by {people} guests"
    
    def free_room(self):
        if not self.is_taken:
            return f"Room number {self.number} is not taken."
        else:
            self.is_taken = False
            self.guests = 0

